/******************************************************************
 * Copyright (c) 2021 Kotaro Tadano
 ******************************************************************/

#ifndef __TS01__
#define __TS01__

#include<ts01/data.h>
#include<ts01/driver.h>
#include<ts01/sim.h>

#endif
